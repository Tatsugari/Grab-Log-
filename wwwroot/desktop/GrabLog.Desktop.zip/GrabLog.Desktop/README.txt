GRAB & LOG — Windows Desktop App (C#)
=====================================

Native Windows desktop app (C# WinForms + WebView2).
Opens your live GrabLog website in its own window.

REQUIREMENTS
------------
1. Windows 10 or 11
2. .NET 10 SDK
   https://dotnet.microsoft.com/download/dotnet/8.0
3. WebView2 Runtime (usually already installed with Edge)
   https://developer.microsoft.com/microsoft-edge/webview2/

URL
---
Default: https://grab-log-production.up.railway.app
Change AppUrl in MainForm.cs if your Railway URL is different.

BUILD & RUN
-----------
Open PowerShell in this folder:

  dotnet restore
  dotnet build -c Release
  dotnet run -c Release

SINGLE .EXE (optional)
----------------------
  dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true

Output:
  bin\Release\net10.0-windows\win-x64\publish\GrabLog.exe

RFID
----
Connect Kiosk works inside this window on the same PC with ESP32 USB.
Use Chrome/Edge WebView2 (this app uses the same engine).

For teachers: Desktop client = C# WinForms + WebView2
              Backend = C# ASP.NET Core on Railway
