@echo off
title GRAB ^& LOG — Build Installer
cd /d "%~dp0"

echo ========================================
echo  1) Publishing GrabLog.exe (self-contained)
echo ========================================
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true
if errorlevel 1 (
  echo PUBLISH FAILED. Install .NET 10 SDK first.
  pause
  exit /b 1
)

echo.
echo Published to:
echo   bin\Release\net10.0-windows\win-x64\publish\GrabLog.exe
echo.

where iscc >nul 2>&1
if errorlevel 1 (
  echo Inno Setup compiler not found in PATH.
  echo.
  echo Option A: Double-click GrabLog.exe in the publish folder to run the app.
  echo Option B: Install Inno Setup from https://jrsoftware.org/isinfo.php
  echo           Then open installer\GrabLog.iss and click Build.
  echo.
  explorer "bin\Release\net10.0-windows\win-x64\publish"
  pause
  exit /b 0
)

echo ========================================
echo  2) Building GrabLog-Setup.exe
echo ========================================
if not exist installer-output mkdir installer-output
iscc installer\GrabLog.iss
if errorlevel 1 (
  echo Inno Setup build failed.
  pause
  exit /b 1
)

echo.
echo DONE. Installer:
echo   installer-output\GrabLog-Setup.exe
explorer installer-output
pause
