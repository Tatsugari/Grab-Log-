using System;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace GrabLog.Desktop;

public class MainForm : Form
{
    // Your live Railway site
    private const string AppUrl = "https://grab-log-production.up.railway.app";

    private readonly WebView2 _web = new();
    private readonly Panel _top = new();
    private readonly Label _status = new();
    private readonly Button _btnReload = new();
    private readonly Button _btnHome = new();

    public MainForm()
    {
        Text = "GRAB & LOG — Tool Room";
        Width = 1280;
        Height = 800;
        MinimumSize = new Size(900, 600);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.FromArgb(12, 12, 12);
        ForeColor = Color.White;

        _top.Dock = DockStyle.Top;
        _top.Height = 42;
        _top.BackColor = Color.FromArgb(22, 22, 22);
        _top.Padding = new Padding(8, 6, 8, 6);

        _btnHome.Text = "Home";
        _btnHome.Width = 72;
        _btnHome.FlatStyle = FlatStyle.Flat;
        _btnHome.FlatAppearance.BorderColor = Color.FromArgb(42, 42, 42);
        _btnHome.BackColor = Color.FromArgb(30, 30, 30);
        _btnHome.ForeColor = Color.FromArgb(255, 204, 0);
        _btnHome.Cursor = Cursors.Hand;
        _btnHome.Dock = DockStyle.Left;
        _btnHome.Click += (_, _) => NavigateHome();

        _btnReload.Text = "Reload";
        _btnReload.Width = 72;
        _btnReload.FlatStyle = FlatStyle.Flat;
        _btnReload.FlatAppearance.BorderColor = Color.FromArgb(42, 42, 42);
        _btnReload.BackColor = Color.FromArgb(30, 30, 30);
        _btnReload.ForeColor = Color.FromArgb(255, 204, 0);
        _btnReload.Cursor = Cursors.Hand;
        _btnReload.Dock = DockStyle.Left;
        _btnReload.Click += (_, _) =>
        {
            if (_web.CoreWebView2 != null)
                _web.CoreWebView2.Reload();
        };

        _status.Text = "Loading GrabLog…";
        _status.ForeColor = Color.FromArgb(138, 138, 138);
        _status.Dock = DockStyle.Fill;
        _status.TextAlign = ContentAlignment.MiddleLeft;
        _status.Padding = new Padding(12, 0, 0, 0);

        _top.Controls.Add(_status);
        _top.Controls.Add(_btnReload);
        _top.Controls.Add(_btnHome);

        _web.Dock = DockStyle.Fill;
        Controls.Add(_web);
        Controls.Add(_top);

        Load += async (_, _) => await InitWebView();
    }

    private async System.Threading.Tasks.Task InitWebView()
    {
        try
        {
            var env = await CoreWebView2Environment.CreateAsync();
            await _web.EnsureCoreWebView2Async(env);
            _web.CoreWebView2.Settings.AreDefaultContextMenusEnabled = true;
            _web.CoreWebView2.Settings.IsStatusBarEnabled = false;

            _web.CoreWebView2.NavigationCompleted += (_, e) =>
            {
                _status.Text = e.IsSuccess
                    ? "Connected — GRAB & LOG desktop (C# / WebView2)"
                    : "Failed to load. Check internet / Railway URL.";
                _status.ForeColor = e.IsSuccess
                    ? Color.FromArgb(34, 197, 94)
                    : Color.FromArgb(239, 68, 68);
            };

            NavigateHome();
        }
        catch (Exception ex)
        {
            _status.Text = "WebView2 missing — install Edge WebView2 Runtime.";
            _status.ForeColor = Color.FromArgb(239, 68, 68);
            MessageBox.Show(
                "Microsoft Edge WebView2 Runtime is required.\n\n" +
                "https://developer.microsoft.com/microsoft-edge/webview2/\n\n" +
                ex.Message,
                "GrabLog Desktop",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
        }
    }

    private void NavigateHome()
    {
        if (_web.CoreWebView2 != null)
            _web.CoreWebView2.Navigate(AppUrl);
        else
            _web.Source = new Uri(AppUrl);
    }
}
